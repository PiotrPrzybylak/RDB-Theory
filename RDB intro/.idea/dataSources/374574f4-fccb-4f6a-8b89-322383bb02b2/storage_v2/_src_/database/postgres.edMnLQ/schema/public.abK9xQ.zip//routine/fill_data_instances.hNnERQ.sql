create function fill_data_instances() returns void
    language plpgsql
as
$$
begin
    for i in 1..60 loop
        INSERT INTO instances VALUES (i, 'InstanceName' || cast(i AS text), 'InstanceDescription' || cast(i AS text), (i % 2 + 1) * 5, (i % 12 + 1) * 5);
        end loop;
end;
$$;

alter function fill_data_instances() owner to postgres;

