create function fill_data_users_achievements() returns void
    language plpgsql
as
$$
begin
    for i in 1..60000 loop
        INSERT INTO users_achievements VALUES (i % 30000 + 1, i % 1000 + 1, to_date('20/10/2020', 'DD/MM/YYYY'));
        end loop;
end;
$$;

alter function fill_data_users_achievements() owner to postgres;

