create function fill_data_users() returns void
    language plpgsql
as
$$
begin
    for i in 1..30000 loop
        INSERT INTO users VALUES (i, 'Login' || cast(i AS text), 'Password' || cast(i AS text), 'Name' || cast(i AS text), to_date('20/10/2020', 'DD/MM/YYYY'));
        end loop;
end;
$$;

alter function fill_data_users() owner to postgres;

