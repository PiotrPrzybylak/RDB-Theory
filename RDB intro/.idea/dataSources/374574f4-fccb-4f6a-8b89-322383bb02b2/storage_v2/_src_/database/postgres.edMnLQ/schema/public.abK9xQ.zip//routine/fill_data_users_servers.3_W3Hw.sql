create function fill_data_users_servers() returns void
    language plpgsql
as
$$
begin
    for i in 1..80000 loop
        INSERT INTO users_servers VALUES (i % 30000 + 1, i % 20 + 1);
        end loop;
end;
$$;

alter function fill_data_users_servers() owner to postgres;

