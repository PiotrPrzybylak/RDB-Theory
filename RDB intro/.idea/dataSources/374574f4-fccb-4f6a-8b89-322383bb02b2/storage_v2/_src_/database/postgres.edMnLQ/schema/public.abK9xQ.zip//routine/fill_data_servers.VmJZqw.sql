create function fill_data_servers() returns void
    language plpgsql
as
$$
begin
    for i in 1..20 loop
        INSERT INTO servers VALUES (i, 'ServerName' || cast(i AS text), 2000, to_date('20/10/2020', 'DD/MM/YYYY'));
        end loop;
end;
$$;

alter function fill_data_servers() owner to postgres;

