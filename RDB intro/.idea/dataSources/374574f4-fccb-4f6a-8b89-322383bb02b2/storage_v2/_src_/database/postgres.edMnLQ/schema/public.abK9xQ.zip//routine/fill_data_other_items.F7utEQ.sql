create function fill_data_other_items() returns void
    language plpgsql
as
$$
begin
    for i in 1..300 loop
        INSERT INTO other_items VALUES (i, true);
        end loop;
end;
$$;

alter function fill_data_other_items() owner to postgres;

