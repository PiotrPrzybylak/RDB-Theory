create function fill_data_skills() returns void
    language plpgsql
as
$$
begin
    for i in 1..300 loop
        INSERT INTO skills VALUES (i, i % 5 + 12, 'Skillname' || cast(i AS text), false);
        end loop;
end;
$$;

alter function fill_data_skills() owner to postgres;

