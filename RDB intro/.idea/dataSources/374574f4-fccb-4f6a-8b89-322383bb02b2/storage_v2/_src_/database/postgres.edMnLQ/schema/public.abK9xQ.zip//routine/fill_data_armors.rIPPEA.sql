create function fill_data_armors() returns void
    language plpgsql
as
$$
begin
    for i in 1..1000 loop
        INSERT INTO armors VALUES (i, i % 3 + 1, i % 20 + 10, i % 20 + 10, i % 20 + 10, i % 20 + 10);
        end loop;
end;
$$;

alter function fill_data_armors() owner to postgres;

