create function fill_data_race_skills() returns void
    language plpgsql
as
$$
begin
    for i in 1..300 loop
        INSERT INTO race_skills VALUES (i % 8 + 1, i);
        end loop;
end;
$$;

alter function fill_data_race_skills() owner to postgres;

