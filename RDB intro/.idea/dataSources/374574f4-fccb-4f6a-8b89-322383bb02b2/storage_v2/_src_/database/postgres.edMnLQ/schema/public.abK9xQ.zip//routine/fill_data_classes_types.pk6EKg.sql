create function fill_data_classes_types() returns void
    language plpgsql
as
$$
begin
    for i in 1..32 loop
        INSERT INTO classes_types VALUES (i % 8 + 1, i % 16 + 1);
        end loop;
end;
$$;

alter function fill_data_classes_types() owner to postgres;

