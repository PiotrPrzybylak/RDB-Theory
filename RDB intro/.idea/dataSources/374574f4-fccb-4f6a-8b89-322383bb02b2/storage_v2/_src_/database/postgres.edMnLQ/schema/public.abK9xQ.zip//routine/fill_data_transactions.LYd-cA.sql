create function fill_data_transactions() returns void
    language plpgsql
as
$$
begin
    for i in 1..360000 loop
        INSERT INTO transactions VALUES (i,  i % 120000 + 1, i % 60000 + 6000, to_date(cast((i % 30 + 1) AS text) ||'/10/2020', 'DD/MM/YYYY'), i % 1200 + 1, i % 4 + 1);
        end loop;
end;
$$;

alter function fill_data_transactions() owner to postgres;

