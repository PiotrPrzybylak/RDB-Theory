create function fill_data_mobs() returns void
    language plpgsql
as
$$
begin
    for i in 1..300 loop
        INSERT INTO mobs VALUES (i, 'MobName' || cast(i AS text), i % 60 + 1, i, i, false, i % 3 + 1);
        end loop;
end;
$$;

alter function fill_data_mobs() owner to postgres;

