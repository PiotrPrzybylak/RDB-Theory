create function fill_data_items() returns void
    language plpgsql
as
$$
begin
    for i in 1..1200 loop
        INSERT INTO items VALUES (i, 'ItemName' || cast(i AS text), 'ItemDescription' || cast(i AS text), i % 100 + 100, i % 60 + 1, i % 4 + 1, i % 300 + 1, i % 4 + 1 );
        end loop;
end;
$$;

alter function fill_data_items() owner to postgres;

