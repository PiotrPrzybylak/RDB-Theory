create function fill_data_jewelery() returns void
    language plpgsql
as
$$
begin
    for i in 1..300 loop
        INSERT INTO jewelery VALUES (i, i % 60 + 1, i % 60 + 1, i % 60 + 1, i % 60 + 1, (i % 60) * 100);
        end loop;
end;
$$;

alter function fill_data_jewelery() owner to postgres;

