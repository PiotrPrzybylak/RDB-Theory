create function fill_data_characters_instances() returns void
    language plpgsql
as
$$
begin
    for i in 1..300000 loop
        INSERT INTO characters_instances VALUES (i % 100000 + 1, i % 60 + 1, to_date(cast((i % 30 + 1) AS text) ||'/10/2020', 'DD/MM/YYYY'));
        end loop;
end;
$$;

alter function fill_data_characters_instances() owner to postgres;

