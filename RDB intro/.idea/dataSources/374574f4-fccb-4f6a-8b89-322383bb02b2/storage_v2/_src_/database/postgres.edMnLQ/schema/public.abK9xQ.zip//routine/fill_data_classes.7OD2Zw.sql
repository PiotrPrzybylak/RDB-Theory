create function fill_data_classes() returns void
    language plpgsql
as
$$
begin
    for i in 1..8 loop
        INSERT INTO classes VALUES (i, 'ClassName' || cast(i AS text));
        end loop;
end;
$$;

alter function fill_data_classes() owner to postgres;

