create function fill_data_weapons() returns void
    language plpgsql
as
$$
begin
    for i in 1..300 loop
        INSERT INTO weapons VALUES (i, i % 8 + 4, i % 60, i % 60, i % 60, i % 60, i % 100);
        end loop;
end;
$$;

alter function fill_data_weapons() owner to postgres;

