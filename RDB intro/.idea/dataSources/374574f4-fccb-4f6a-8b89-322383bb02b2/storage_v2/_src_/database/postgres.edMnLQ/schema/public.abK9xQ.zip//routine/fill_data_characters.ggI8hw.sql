create function fill_data_characters() returns void
    language plpgsql
as
$$
begin
    for i in 1..120000 loop
        INSERT INTO characters VALUES (i, 'Nickname' || cast(i AS text), 20, to_date(cast((i % 30 + 1) AS text) ||'/10/2020', 'DD/MM/YYYY'), i % 8 + 1, i % 8 + 1, to_date(cast((i % 30 + 1) AS text) ||'/10/2020', 'DD/MM/YYYY'), i % 20 + 1);
        end loop;
end;
$$;

alter function fill_data_characters() owner to postgres;

