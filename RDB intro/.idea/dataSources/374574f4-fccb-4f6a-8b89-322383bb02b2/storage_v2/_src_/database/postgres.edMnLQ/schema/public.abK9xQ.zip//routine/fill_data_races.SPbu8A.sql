create function fill_data_races() returns void
    language plpgsql
as
$$
begin
    for i in 1..8 loop
        INSERT INTO races VALUES (i,'RaceName' || cast(i AS text));
        end loop;
end;
$$;

alter function fill_data_races() owner to postgres;

