create function fill_data_achievements() returns void
    language plpgsql
as
$$
begin
    for i in 1..1000 loop
        INSERT INTO achievements VALUES (i, 'Achievement' || cast(i AS text), 'Description' || cast(i AS text));
        end loop;
end;
$$;

alter function fill_data_achievements() owner to postgres;

